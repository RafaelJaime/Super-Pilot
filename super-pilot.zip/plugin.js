console.log('[SuperPilot] Plugin loaded');
